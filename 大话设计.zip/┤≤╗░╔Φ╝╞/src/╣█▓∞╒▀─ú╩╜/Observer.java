package 观察者模式;

public abstract class Observer
{
    public abstract void update();
}
