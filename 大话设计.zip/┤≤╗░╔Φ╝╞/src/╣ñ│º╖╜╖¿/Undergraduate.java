package 工厂方法;
//学雷锋的大学生类，继承雷锋
public class Undergraduate extends LeiFeng
{

}
