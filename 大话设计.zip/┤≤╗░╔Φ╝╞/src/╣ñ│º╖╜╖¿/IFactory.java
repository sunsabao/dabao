package 工厂方法;
//雷锋工厂
public interface IFactory {
    LeiFeng createLeiFeng();
}
