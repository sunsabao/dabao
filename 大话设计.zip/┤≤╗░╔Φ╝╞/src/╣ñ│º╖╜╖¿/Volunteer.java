package 工厂方法;
//社区志愿者
public class Volunteer extends LeiFeng
{

}