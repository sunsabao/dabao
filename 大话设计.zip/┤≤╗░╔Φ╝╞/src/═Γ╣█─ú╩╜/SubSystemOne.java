package 外观模式;
//四个子系统的类
public class SubSystemOne {
    public void methodOne()
    {
        System.out.println("子系统方法1");
    }
}
 class SubSystemTwo
{
    public void methodTwo()
    {
        System.out.println("子系统方法2");
    }
}
 class SubSystemThree
{
    public void methodThree()
    {
        System.out.println("子系统方法3");
    }
}
 class SubSystemFour
{
    public void methodFour()
    {
        System.out.println("子系统方法4");
    }
}

