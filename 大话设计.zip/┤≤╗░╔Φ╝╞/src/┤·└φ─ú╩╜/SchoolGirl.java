package 代理模式;
//被追求者
public class SchoolGirl {
    public String	name;

    public String getName()
    {
        return this.name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

