package 代理模式;
//代理接口
public interface GiveGift {
    void giveDolls();

    void giveFlowers();

    void giveChocolate();
}
